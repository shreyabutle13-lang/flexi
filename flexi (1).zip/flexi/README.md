# FLEXI – Task & Project Manager (MERN)

Full-stack web app: **React (Vite)** frontend, **Node.js + Express** backend, **MongoDB** database (viewable in MongoDB Compass).

## Features
- Create / delete projects
- Create / edit / delete tasks inside a project
- Task status (To Do, In Progress, Done), priority, due date
- Kanban-style board; overdue tasks highlighted
- All data is stored in and read from MongoDB

## Structure
```
flexi/
├── backend/    Express API + Mongoose models (Project, Task)
└── frontend/   React app (Vite) – proxies /api to the backend
```

## Prerequisites
- Node.js 18+
- MongoDB running locally (default `mongodb://127.0.0.1:27017`) and MongoDB Compass

## Run it

**1. Backend**
```bash
cd backend
cp .env.example .env      # on Windows: copy .env.example .env
npm install
npm run dev               # or: npm start   → http://localhost:5000
```

**2. Frontend** (new terminal)
```bash
cd frontend
npm install
npm run dev               # → http://localhost:5173
```

**3. View data in MongoDB Compass**
Connect to `mongodb://127.0.0.1:27017`, open database `flexi`, collections `projects` and `tasks`.

## API
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/projects` | List projects |
| POST | `/api/projects` | Create project `{name, description?, color?}` |
| PUT | `/api/projects/:id` | Update project |
| DELETE | `/api/projects/:id` | Delete project and its tasks |
| GET | `/api/tasks?project=<id>&status=<s>` | List tasks (filters optional) |
| POST | `/api/tasks` | Create task `{title, project, description?, status?, priority?, dueDate?}` |
| PUT | `/api/tasks/:id` | Update task |
| DELETE | `/api/tasks/:id` | Delete task |
