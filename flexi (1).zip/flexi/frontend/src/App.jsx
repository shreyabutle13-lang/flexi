import { useEffect, useState } from 'react';
import { api } from './api';
import ProjectSidebar from './components/ProjectSidebar.jsx';
import TaskBoard from './components/TaskBoard.jsx';

export default function App() {
  const [projects, setProjects] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [error, setError] = useState('');

  const loadProjects = async () => {
    try {
      const data = await api.getProjects();
      setProjects(data);
      setActiveId((cur) => (data.some((p) => p._id === cur) ? cur : data[0]?._id ?? null));
      setError('');
    } catch (e) {
      setError(e.message);
    }
  };

  useEffect(() => {
    loadProjects();
  }, []);

  const addProject = async (project) => {
    const created = await api.createProject(project);
    setProjects((p) => [created, ...p]);
    setActiveId(created._id);
  };

  const removeProject = async (id) => {
    await api.deleteProject(id);
    await loadProjects();
  };

  const activeProject = projects.find((p) => p._id === activeId);

  return (
    <div className="app">
      <ProjectSidebar
        projects={projects}
        activeId={activeId}
        onSelect={setActiveId}
        onAdd={addProject}
        onDelete={removeProject}
      />
      <main className="main">
        {error && <div className="error">Could not reach the server: {error}</div>}
        {activeProject ? (
          <TaskBoard key={activeProject._id} project={activeProject} />
        ) : (
          <div className="empty">Create a project to get started.</div>
        )}
      </main>
    </div>
  );
}
