import { useState } from 'react';

const COLORS = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#06b6d4', '#ef4444'];

export default function ProjectSidebar({ projects, activeId, onSelect, onAdd, onDelete }) {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      await onAdd({ name: name.trim(), color: COLORS[projects.length % COLORS.length] });
      setName('');
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <aside className="sidebar">
      <h1 className="logo">FLEXI</h1>
      <form onSubmit={submit} className="project-form">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="New project name"
        />
        <button type="submit">Add</button>
      </form>
      {error && <p className="error small">{error}</p>}
      <ul className="project-list">
        {projects.map((p) => (
          <li
            key={p._id}
            className={p._id === activeId ? 'active' : ''}
            onClick={() => onSelect(p._id)}
          >
            <span className="dot" style={{ background: p.color }} />
            <span className="pname">{p.name}</span>
            <button
              className="icon-btn"
              title="Delete project"
              onClick={(e) => {
                e.stopPropagation();
                if (window.confirm(`Delete "${p.name}" and all its tasks?`)) onDelete(p._id);
              }}
            >
              ×
            </button>
          </li>
        ))}
      </ul>
    </aside>
  );
}
