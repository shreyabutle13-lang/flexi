const STATUSES = [
  { key: 'todo', label: 'To Do' },
  { key: 'in-progress', label: 'In Progress' },
  { key: 'done', label: 'Done' },
];

export default function TaskCard({ task, onEdit, onDelete, onStatus }) {
  const overdue =
    task.dueDate && task.status !== 'done' && new Date(task.dueDate) < new Date();

  return (
    <div className="card">
      <div className="card-top">
        <strong>{task.title}</strong>
        <span className={`badge ${task.priority}`}>{task.priority}</span>
      </div>
      {task.description && <p className="desc">{task.description}</p>}
      {task.dueDate && (
        <p className={`due ${overdue ? 'overdue' : ''}`}>
          Due {new Date(task.dueDate).toLocaleDateString()}
        </p>
      )}
      <div className="card-actions">
        <select value={task.status} onChange={(e) => onStatus(e.target.value)}>
          {STATUSES.map((s) => (
            <option key={s.key} value={s.key}>
              {s.label}
            </option>
          ))}
        </select>
        <button className="link" onClick={onEdit}>
          Edit
        </button>
        <button
          className="link danger"
          onClick={() => window.confirm('Delete this task?') && onDelete()}
        >
          Delete
        </button>
      </div>
    </div>
  );
}
