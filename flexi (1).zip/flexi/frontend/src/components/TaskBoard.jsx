import { useEffect, useState } from 'react';
import { api } from '../api';
import TaskForm from './TaskForm.jsx';
import TaskCard from './TaskCard.jsx';

const COLUMNS = [
  { key: 'todo', label: 'To Do' },
  { key: 'in-progress', label: 'In Progress' },
  { key: 'done', label: 'Done' },
];

export default function TaskBoard({ project }) {
  const [tasks, setTasks] = useState([]);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .getTasks(project._id)
      .then(setTasks)
      .catch((e) => setError(e.message));
  }, [project._id]);

  const saveTask = async (data) => {
    if (editing) {
      const updated = await api.updateTask(editing._id, { ...data, project: project._id });
      setTasks((t) => t.map((x) => (x._id === updated._id ? updated : x)));
      setEditing(null);
    } else {
      const created = await api.createTask({ ...data, project: project._id });
      setTasks((t) => [created, ...t]);
    }
  };

  const changeStatus = async (task, status) => {
    const updated = await api.updateTask(task._id, { ...task, status });
    setTasks((t) => t.map((x) => (x._id === updated._id ? updated : x)));
  };

  const removeTask = async (id) => {
    await api.deleteTask(id);
    setTasks((t) => t.filter((x) => x._id !== id));
  };

  return (
    <section>
      <header className="board-header">
        <h2>{project.name}</h2>
        <span className="count">{tasks.length} tasks</span>
      </header>
      {error && <div className="error">{error}</div>}

      <TaskForm
        key={editing?._id || 'new'}
        initial={editing}
        onSave={saveTask}
        onCancel={() => setEditing(null)}
      />

      <div className="columns">
        {COLUMNS.map((col) => {
          const items = tasks.filter((t) => t.status === col.key);
          return (
            <div className="column" key={col.key}>
              <h3>
                {col.label} <span className="count">{items.length}</span>
              </h3>
              {items.map((t) => (
                <TaskCard
                  key={t._id}
                  task={t}
                  onEdit={() => setEditing(t)}
                  onDelete={() => removeTask(t._id)}
                  onStatus={(s) => changeStatus(t, s)}
                />
              ))}
              {items.length === 0 && <p className="muted">Nothing here</p>}
            </div>
          );
        })}
      </div>
    </section>
  );
}
