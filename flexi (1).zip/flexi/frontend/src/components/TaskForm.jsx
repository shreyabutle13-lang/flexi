import { useState } from 'react';

const empty = { title: '', description: '', priority: 'medium', status: 'todo', dueDate: '' };

export default function TaskForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState(
    initial
      ? { ...initial, dueDate: initial.dueDate ? initial.dueDate.slice(0, 10) : '' }
      : empty
  );
  const [error, setError] = useState('');

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      setError('Title is required');
      return;
    }
    try {
      await onSave({
        title: form.title.trim(),
        description: form.description,
        priority: form.priority,
        status: form.status,
        dueDate: form.dueDate || null,
      });
      if (!initial) setForm(empty);
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <form className="task-form" onSubmit={submit}>
      <input placeholder="Task title" value={form.title} onChange={set('title')} />
      <input placeholder="Description (optional)" value={form.description} onChange={set('description')} />
      <select value={form.priority} onChange={set('priority')}>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
      <input type="date" value={form.dueDate} onChange={set('dueDate')} />
      <button type="submit">{initial ? 'Update' : 'Add task'}</button>
      {initial && (
        <button type="button" className="secondary" onClick={onCancel}>
          Cancel
        </button>
      )}
      {error && <span className="error small">{error}</span>}
    </form>
  );
}
