import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Proxy /api to the Node backend so the frontend can call it without CORS issues
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:5000',
    },
  },
});
