const express = require('express');
const Task = require('../models/Task');

const router = express.Router();

const pick = (body) => {
  const { title, description, status, priority, dueDate, project } = body;
  const data = { title, description, status, priority, dueDate: dueDate || undefined, project };
  Object.keys(data).forEach((k) => data[k] === undefined && delete data[k]);
  return data;
};

// GET tasks (optional ?project=<id>&status=<status>)
router.get('/', async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.project) filter.project = req.query.project;
    if (req.query.status) filter.status = req.query.status;
    res.json(await Task.find(filter).sort({ createdAt: -1 }));
  } catch (e) {
    next(e);
  }
});

// CREATE
router.post('/', async (req, res, next) => {
  try {
    res.status(201).json(await Task.create(pick(req.body)));
  } catch (e) {
    next(e);
  }
});

// UPDATE
router.put('/:id', async (req, res, next) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, pick(req.body), {
      new: true,
      runValidators: true,
    });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json(task);
  } catch (e) {
    next(e);
  }
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch (e) {
    next(e);
  }
});

module.exports = router;
