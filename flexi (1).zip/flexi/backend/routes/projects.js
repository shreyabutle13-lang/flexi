const express = require('express');
const Project = require('../models/Project');
const Task = require('../models/Task');

const router = express.Router();

// GET all projects
router.get('/', async (req, res, next) => {
  try {
    res.json(await Project.find().sort({ createdAt: -1 }));
  } catch (e) {
    next(e);
  }
});

// GET one project
router.get('/:id', async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
  } catch (e) {
    next(e);
  }
});

// CREATE
router.post('/', async (req, res, next) => {
  try {
    const { name, description, color } = req.body;
    res.status(201).json(await Project.create({ name, description, color }));
  } catch (e) {
    next(e);
  }
});

// UPDATE
router.put('/:id', async (req, res, next) => {
  try {
    const { name, description, color } = req.body;
    const project = await Project.findByIdAndUpdate(
      req.params.id,
      { name, description, color },
      { new: true, runValidators: true }
    );
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
  } catch (e) {
    next(e);
  }
});

// DELETE (also removes its tasks)
router.delete('/:id', async (req, res, next) => {
  try {
    const project = await Project.findByIdAndDelete(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    await Task.deleteMany({ project: project._id });
    res.json({ message: 'Project deleted' });
  } catch (e) {
    next(e);
  }
});

module.exports = router;
